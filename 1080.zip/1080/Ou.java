package Tel;
public class Ou
{
public void show()
{
System.out.println("ou");
}
}
//Streams--->ObjectInputStreams
import java.io.*;
class Emp implements Serializable
{
    int x;
    String s;
}
class OIC1
{
    public static void main(String arg[]) throws IOException,ClassNotFoundException
    {
        FileInputStream fis=new FileInputStream("11.txt");
        ObjectInputStream is=new ObjectInputStream(fis);
        Emp obj;
        obj=(Emp)is.readObject();
        System.out.println(obj.x+obj.s);
        fis.close();
        is.close();
    }
}
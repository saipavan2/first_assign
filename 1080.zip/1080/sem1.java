//constructors
class Sem1
{
	Sem1()
	{
		System.out.println("no arguments");
	}
	void show()
	{
		System.out.println(" iam show method");
	}
}
class Mainn
{
	public static void main(String args[])
	{
		Sem1 obj=new Sem1();
		obj.show();
		System.out.println("address"+obj);
	}
}
package SRU5;

public class Csee
{
	public void show()
	{
		System.out.println("cse e");
		
	}
}
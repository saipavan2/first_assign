package SRU;
public class CseA
{
public void show()
{
System.out.println("cse a");
}
}
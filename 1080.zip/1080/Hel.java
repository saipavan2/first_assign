import java.util.*;
import java.lang.Throwable;
class exp1 extends Throwable
{
	exp1()
	{
	System.out.println(" years");
	}
}
class Hel
{
	public static void main(String arg[])
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the age:");
			int age=sc.nextInt();
			if(age<=18)
			{
			throw new exp1();
			}
			else
			{
				System.out.println("vote");
			}
		}
		catch(Throwable e)
		{
			System.out.println(e);
		}
	}
}
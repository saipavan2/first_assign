import java.util.*;
class Hel
{
void method() throws ArithmeticException,ArrayIndexOutOfBoundsException
{
int a[]=new int[10];
a[11]=22;
int u=0;
int f=20/u;
}
}
class Maa1
{
public static void main(String args[])
{
try
{
Hel obj=new Hel();
obj.method();
}catch(ArithmeticException e)
{
System.out.println("artjik");
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("stay in limits");
}
}
}
import java.util.*;
class Fre
{
public static void main(String args[])
{
int count=0,j;
Scanner sc=new Scanner(System.in);
System.out.println("enter the string:");
String str=sc.nextLine();
int len=str.length(),i;
for(i=0;i<len;i++)
{
char st1=str.charAt(i);
for(j=0;j<len;j++)
{
if(st1==str.charAt(j))
{
count=count+1;
}
}
System.out.println(st1=count);
count=0;
}

}
}
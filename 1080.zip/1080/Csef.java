package SRU5;
public class Csef
{
	public void show()
	{
		System.out.println("cse f");
	}
}
class Box
{
int lenght;
int breadth;
int depth;
}
class MainClass
{
public static void main(String args[])
{
  Box mybox=new Box();
  mybox.lenght=10;
  mybox.breadth=20;
  mybox.depth=40;

int vol=mybox.lenght*mybox.breadth*mybox.depth;
System.out.println("volume is:"+vol);

}
}
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class aadharcard{
    public static void main(String args[]){
        new aadharcard();
    }
    private JFrame frame;
    private JTextField numberField;
    private JLabel validLabel;
    private JButton verifyButton;
    public aadharcard(){
        frame =new  JFrame("Aadharcard Number Verifier");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(350,400));
        numberField=new JTextField(12);
        validLabel = new JLabel("not yet verified");
        verifyButton= new JButton("Verify Aadharcard Number");

        verifyButton.addActionListener(new VerifyListener());

        frame.setLayout(new FlowLayout());
        frame.add(numberField);
        frame.add(verifyButton);
        frame.add(validLabel);
        frame.setVisible(true);
    }
       public static boolean  IsValidAadharcardNumber(String number) {
       if(number.matches ("\\d{12}"))
        {
            return true;
        }
        else
        {
           return false;
        }
}
        

    
    public class VerifyListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            String number = numberField.getText();
            if ( IsValidAadharcardNumber(number)) {
                validLabel.setText("Valid number!");
            } else {
                validLabel.setText("Invalid number.");
            }
        }
        }
    }
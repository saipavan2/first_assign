import java.util.Scanner;
class Exp extends Exception 
{ 
	Exp(int age)
	{
		int c=18-age;
		System.out.println("whait for:"+c+" years");
	}
}
class Ans
{
	public static void main(String args[])
	{
		//class_name obj = new class_name();
		try{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the age :");
		int age = sc.nextInt();
		if(age<=18)
		{
			throw new Exp(age);
		}
		else{
			System.out.println("you are eligible for voting");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
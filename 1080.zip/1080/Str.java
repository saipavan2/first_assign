class Str
{
public static void main(String args[])
{
char ch[]={'a','b','c','d'};
String s=new String(ch);

System.out.println(s);


}
}

class MultithreadingDemo extends Thread 
{
	public void run()
	{
		System.out.println("Thread " + Thread.currentThread().getId()+ " is running");
	}
}


public class Multithread
 {
	public static void main(String[] args)
	{
		int n = 8; 
		for (int i = 0; i < n; i++)
		{
			MultithreadingDemo t1=new MultithreadingDemo();
			t1.start();
			try
			{
			Thread.sleep(500);
	        }
            catch(Exception e)
            {
				
			}			
		}
	}
}

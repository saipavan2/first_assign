import java.util.*;
class Pal
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a string:");
String str=sc.nextLine();
System.out.println("string:"+str);
int j=str.length(),i=0,fre=str.length();

while(fre!=0)
{
if(str.charAt(i)==str.charAt(j-1))
{
i++;
j--;
fre=fre-1;
continue;
}
else
{
System.out.println("NOT palin");
break;
}


}
if(fre==0)
{
System.out.println("palin");
}
}
}


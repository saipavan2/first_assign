package Punjab;
public class Iit1
{
	public void show()
	{
		System.out.println("iit panjab");
	}
}
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
@SuppressWarnings("serial")
public class Agri extends JFrame implements ActionListener{
	
	
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JButton btnNewButton;
	private JButton btnCancel;
	private JButton btnClick;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Agri window = new Agri();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	private Agri() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("No.of Acres:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(50, 39, 71, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblLoanReceived = new JLabel("Loan Received:");
		lblLoanReceived.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblLoanReceived.setBounds(35, 66, 86, 23);
		frame.getContentPane().add(lblLoanReceived);
		
		JLabel lblQuintasProduced = new JLabel("Quintas Produced:");
		lblQuintasProduced.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblQuintasProduced.setBounds(16, 90, 105, 23);
		frame.getContentPane().add(lblQuintasProduced);
		
		JLabel lblNoofWorkers = new JLabel("No.of Workers:");
		lblNoofWorkers.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNoofWorkers.setBounds(35, 116, 86, 23);
		frame.getContentPane().add(lblNoofWorkers);
		
		JLabel lblNoofUreaBags = new JLabel("No.of Urea bags:");
		lblNoofUreaBags.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNoofUreaBags.setBounds(23, 137, 111, 23);
		frame.getContentPane().add(lblNoofUreaBags);
		
		JLabel lblNoofDapBags = new JLabel("No.of DAP bags:");
		lblNoofDapBags.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNoofDapBags.setBounds(26, 162, 95, 23);
		frame.getContentPane().add(lblNoofDapBags);
		
		JLabel lblFertilizersCost = new JLabel("Fertilizers Cost: ");
		lblFertilizersCost.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFertilizersCost.setBounds(26, 183, 95, 23);
		frame.getContentPane().add(lblFertilizersCost);
		
		textField = new JTextField();
		textField.setBounds(131, 45, 95, 17);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(131, 69, 95, 17);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(131, 93, 95, 17);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(131, 119, 95, 17);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(131, 140, 95, 17);
		frame.getContentPane().add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(131, 165, 95, 17);
		frame.getContentPane().add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(131, 186, 95, 17);
		frame.getContentPane().add(textField_6);
		
		JLabel lblNewLabel_1 = new JLabel("OUTPUT");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(214, 221, 64, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		btnNewButton = new JButton("SUBMIT");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(236, 161, 102, 23);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(this);
		
		btnCancel = new JButton("CANCEL");
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCancel.setBounds(361, 162, 85, 21);
		frame.getContentPane().add(btnCancel);
		btnCancel.addActionListener(this);
		
		btnClick = new JButton("OUTPUT");
		btnClick.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnClick.setBounds(291, 194, 105, 23);
		frame.getContentPane().add(btnClick);
		btnClick.addActionListener(this);
		
		JTextArea textArea = new JTextArea(" ");
		textArea.setBounds(30, 244, 416, 197);
		frame.getContentPane().add(textArea);
	}
	
	//Scanner sc=new Scanner(System.in);
	//System.out.println("how much acres of land for farmer have:");
	int acres,loan,sizeofcrop,no_of_workers,no_of_urea_bags,no_of_dap_bags,cost_fertilizers;
	int totalprofit,total_expen,totalurea,totaldap,totalworkers,totalferti,d,e;
	//System.out.println("enter the loan gotten to the farmer for agriculture expenditures:");
	int mirchi_market_price=20000;
	int cotton_market_price=2000;
	int paddy_market_price=2000;
	int maize_market_price=2000;

	int urea_price=1500;
	int dap_price=2000;
	//int fertilizers=5000;
	int worker=300;
	int cotton,paddy,mize;
	
	//@Override
	public void actionPerformed(ActionEvent ae) {
		
		String acres1,loan1,sizeofcrop1,no_of_workers1,no_of_urea_bags1,no_of_dap_bags1,cost_fertilizers1;
		
		if(ae.getSource()==btnNewButton)
		{
			acres1=textField.getText();
			acres=Integer.parseInt(acres1);
			
			loan1=textField_1.getText();
			loan=Integer.parseInt(loan1);
			
			sizeofcrop1=textField_2.getText();
			sizeofcrop=Integer.parseInt(sizeofcrop1);
			
			no_of_workers1=textField_3.getText();
			no_of_workers=Integer.parseInt(no_of_workers1);
			
			no_of_urea_bags1=textField_4.getText();
			no_of_urea_bags=Integer.parseInt(no_of_urea_bags1);
			
			no_of_dap_bags1=textField_5.getText();
			no_of_dap_bags=Integer.parseInt(no_of_dap_bags1);
			
			cost_fertilizers1=textField_6.getText();
			cost_fertilizers=Integer.parseInt(cost_fertilizers1);
		}
		
		if(ae.getSource()==btnClick)
		{
			totalprofit=mirchi_market_price*sizeofcrop;
			totalurea=urea_price*no_of_urea_bags;
			totaldap=dap_price*no_of_dap_bags;
			totalworkers=worker*no_of_workers;
			totalferti=cost_fertilizers;
			total_expen=totalurea+totaldap+totalworkers+totalferti;
			d=totalprofit-total_expen;
			
			textArea.setText("hi");
			
			System.out.println("money gotten by farmer after selling his crop: "+totalprofit);
			System.out.println("total urea cost consumed for this year: "+totalurea);
			System.out.println("total dap cost consumed for this year: "+totaldap);
			System.out.println("total money going to workers in a year: "+totalworkers);
			System.out.println("fertilizers cost consumed in thsi year:"+totalferti);
			System.out.println("toal expenditure fot this year for crop: "+total_expen);
			
			
			if(totalprofit>total_expen)
			{
			
				System.out.println("chance you have profit :"+d);
				System.out.println("go with mirch crop better");	
			}
			else
			{
				e=total_expen-loan;
				System.out.println("!!!you are in losss!!!please do not put this crop");
			}
			
			
			if(d<cotton)
			{
				System.out.println("Dear farmer  you have chance for profit on cotton crop better than mirchi crop");
				System.out.println("Dear farmer go for cotton crop");
				System.out.println("Because this mirchi crop using more number of urea bags,this was killing your profit");
				
			}
			
			if(d<paddy)
			{
				System.out.println("Dear farmer  you have chance for profit on paddy crop better than mirchi crop");
				System.out.println("Dear farmer you also have a chance for paddy go with paddy crop");	
				System.out.println("Dear farmer paddy crop requires less number of urea bags");
				System.out.println("paddy requires less number of workers");
			}
			
			
		}
		
		if(ae.getSource()==btnCancel)
		{
			textField.setText("");textField_1.setText("");textField_2.setText("");textField_3.setText("");textField_4.setText("");textField_5.setText("");
			textField_6.setText("");
		}
	}
}
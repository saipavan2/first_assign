package SRU;
public class Cse3
{
public void show()
{
System.out.println("cse3");
}
}
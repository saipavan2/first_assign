class BookTickets
{
	static int total_seats=20;
	synchronized static void Book(int seats)
	{
		if(seats<=total_seats)
		{
			System.out.println("sucessfully booked:");
			total_seats=total_seats-seats;
			System.out.println("reamaing seats:"+total_seats);
			
		}
		else
		{
			System.out.println("no seats:");
		}
	}
}
class MyThread1 extends Thread
{
	BookTickets b;
	int seats;
	MyThread1(BookTickets b,int seats)
	{
		this.b=b;
		this.seats=seats;
		
	}
	public void run()
	{
		b.Book(seats);
		
	}
}
class MyThread2 extends Thread
{
	BookTickets b;
	int seats;
	MyThread2(BookTickets b,int seats)
	{
		this.b=b;
		this.seats=seats;
	}
	public void run()
	{
		b.Book(seats);
	}
}
class Maa3
{
	public static void main(String args[])
	{
		BookTickets b1=new BookTickets();
		MyThread1 t1=new MyThread1(b1,7);
		t1.start();
	    MyThread2 t2=new MyThread2(b1,5);
		t2.start();
		
		BookTickets b2=new BookTickets();
		MyThread1 t3=new MyThread1(b2,3);
		t3.start();
		MyThread2 t4=new MyThread2(b2,9);
		t4.start();
		
	}
}

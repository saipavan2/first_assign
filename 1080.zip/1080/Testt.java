import javax.swing.*;
class Testt extends JFrame
{
	ImageIcon image1;
	Testt()
	{
		image1=new ImageIcon(getClass().getResource("images.png"));
		this.add(image1);
		   this.setSize(400,400);  
        this.setVisible(true);  
		
	}
	
	
	public static void main(String args[])
	{
		new Testt();
	}
}
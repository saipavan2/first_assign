import SRU.*;
public class Maaa
{
public static void main(String args[])
{
SRU.Cse1 obj1=new SRU.Cse1();
SRU.Cse2 obj2=new SRU.Cse2();
SRU.Cse3 obj3=new SRU.Cse3();
obj1.show();
obj2.show();
obj3.show();

}
}
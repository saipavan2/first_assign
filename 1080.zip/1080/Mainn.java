import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
public class Mainn extends JFrame implements ActionListener
{
	JButton b1;
	JTextField tf1;
	
	Mainn()
	{
		
		
	       tf1=new JTextField();
		   tf1.setBounds(50,50,200,30);
		   this.add(tf1);
		   
		   b1=new JButton("press");
		   b1.setBounds(50,100,150,30);
		   this.add(b1);
		  b1.addActionListener(this);
		   
		   this.setLayout(null);
		   this.setSize(900,900);
		   this.setVisible(true);
		   
	}
	public void actionPerformed(ActionEvent ae)
	{
	char temp;
		
		if(ae.getSource()==b1)
		{
			String str=tf1.getText();
		char arr[]=str.toCharArray();
		
	for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
			
		   if(arr[i]>arr[j])
		   {
			   temp=arr[i];
			   arr[i]=arr[j];
			   arr[j]=temp;
			   
		   
			}
		}
		   
	}
	String str2=new String(arr);
	System.out.println(str2);
	
	
	
	}
	
	
	
	
	
	}
	
	
	
	
	
	
	public static void main(String args[])
	{
		new Mainn();
		
	}
	
}
package Ap;
public class It
{
public void show()
{
System.out.println("IT");
}
}
import Sad.*;
import Sad1.*;
public class S2
{
 public static void main(String arg[])
{
     Sad.S1 obj1=new Sad.S1();
      obj1.show();
     Sad1.S0 obj2=new Sad1.S0();
     obj2.display();
 
}
}
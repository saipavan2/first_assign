package Sad;
public class S1
{
public void show()
{
System.out.println("sadiq");
}

}
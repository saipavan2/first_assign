package Bihar;
interface I1
{
	public void show();
	int a=10;
}
public class Iit implements I1
{
	public void show()
	{
		System.out.println("iit madras");
		System.out.println(10);
	}
}
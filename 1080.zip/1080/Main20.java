class Box
{

int width;
int height;
int depth;

Box(int w,int h,int d)
{
width=w;
height=h;
depth=d;
}
int volume()
{
return width*height*depth;
}

}
class Main20
{
public static void main(String args[])
{
Box mybox1=new Box(1,2,3);
int vol;
vol=mybox1.volume();
System.out.println("volume:"+vol);
}


}

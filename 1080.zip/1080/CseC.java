package SRU1;
public class CseC
{
public void show()
{
System.out.println("cse c");
}
}
package Bengal;
public class Iit2
{
	public void show()
	{
		System.out.println("iit Bengal");
	}
}
import javax.swing.*;
import java.applet.*;
import java.awt.*;

import java.io.*;
import java.util.*;
class Test
{
	/*public static void main(String args[])
	{
		try
		{
		System.out.println("enter the salary of month:");
		Scanner sc=new Scanner(System.in);
		int month_salary=sc.nextInt();
		int Actual_oil=1000;
		int Actual_sugar=500;
		int Actual_senamon=1000;
		int Actual_rice=2000;
		for(int year=2022;year<2030;year++)
		{
				System.out.println("year="+year);
		for(int month=1;month<=12;month++)
		{
		System.out.println("enter the oil price consumed for :"+month+"month");
		int oil=sc.nextInt();
		FileOutputStream foil=new FileOutputStream("oil.txt");
		foil.write(oil);
		System.out.println("enter the sugar price consumed for :"+month+"month");
		int sugar=sc.nextInt();
		FileOutputStream fsugar=new FileOutputStream("sugar.txt");
		fsugar.write(sugar);
		System.out.println("enter the senamon price consumed for :"+month+"month");
		int senamon=sc.nextInt();
		FileOutputStream fsenamon=new FileOutputStream("senamon.txt");
		fsugar.write(senamon);
		System.out.println("enter the rice price consumed for :"+month+"month");
		int rice=sc.nextInt();
		FileOutputStream frice=new FileOutputStream("rice.txt");
		fsugar.write(rice);
		
		
		FileInputStream fioil=new FileInputStream("oil.txt");
		FileInputStream fisugar=new FileInputStream("sugar.txt");
		FileInputStream fisenamon=new FileInputStream("senamon.txt");
		FileInputStream firice=new FileInputStream("rice.txt");
		
		
		int total_consumed_price=fioil.read()+fisugar.read()+fisenamon.read()+firice.read();
	
		System.out.println("month="+month);
		System.out.println("SALARY of house:"+month_salary);
		System.out.println("This month cost consumed of house:"+total_consumed_price);
		System.out.println("This month savings:"+(month_salary-total_consumed_price));
		if(total_consumed_price<month_salary)
		{
			System.out.println("Well You Saved Something for your future...");
		}
		else
		{
			System.out.println("your expenditure is more than your salary.try to controll your expenditure");
			
		}
		if(Actual_oil<oil)
		{
			System.out.println("Your oil consumption is greater than health condtion ");
			System.out.println("Oil is dangerious to health.it will give heart stroke");
		    System.out.println("Your family making environment damage ");
		}
		else
		{
			System.out.println("GOOD...your u using limitied oil as condtion");
		}
		if(Actual_sugar<sugar)
		{
			System.out.println("there is chance for diabetes");
		}
		else
		{
			System.out.println("Well consuption of sugar...keep it up");
		}
	
		
		}
		
		}
		}catch(Exception e)
		{
		}
		
		

	}*/
}
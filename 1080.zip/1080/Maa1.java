class A
{
public void show()
{
System.out.println("no arg");
}
public void show(int a)
{
System.out.println("one arg");
}
}
class B extends A
{
public void show()
{
super.show();
System.out.println("no arg");
}
public void show(int a)
{

System.out.println("one arg");
}

}

class Maa1
{
public static void main(String args[])
{

B obj=new B();
obj.show();
}
}
import Tel.*;
import Ap.*;
class Mac
{
public static void main(String args[])
{
Tel.Ou obj1=new Tel.Ou();
Tel.Sr obj2=new Tel.Sr();
Ap.Kak obj3=new Ap.Kak();
Ap.It obj4=new Ap.It();

obj1.show();
obj2.show();
obj3.show();
obj4.show();


}
}
package SRU;
public class Cse1
{
public void show()
{
System.out.println("cse1");
}
}
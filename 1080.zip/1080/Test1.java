import javax.swing.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*; 
 import java.util.Scanner;  
 import java.util.Random;  
 import java.lang.Exception;
 
import javax.swing.plaf.LayerUI;

import java.io.*;
import java.util.*;

		 
		class Emp implements Serializable
{
	int oil;
	int sugar;
	int senamon;
	int rice;
	
}



class Test1 extends JFrame implements ActionListener
{
	
	
		
		JFrame f1,f2,f3,f4,f5,f6,f7;
		JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17,b18,b19,b20,b21;
		JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11,tf12,tf13,tf14,tf15,tf16,tf17,tf18,tf19,tf20;
		JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24,l25,l26,l27,l28,l29,l30,l31,l32,l33,l34,
		l35,l36,l37,l38,l39,l40,l41,l42,l43,l44,l45,l46,l47;
	 Test1()
	{
		
			
		
		
		
		
		f1=new JFrame("frame 1");
		
		int u=0;
		int Actual_oil=1000;
		int Actual_sugar=500;
		int Actual_senamon=1000;
		int Actual_rice=2000;
	
		
		
		

		
		
		l1=new JLabel("Enter Cost of Grains & Tiffin Iteams Consumption");
		l1.setBounds(50,50,1000,30);
		f1.add(l1);
		
		tf1=new JTextField();
		tf1.setBounds(50,80,100,30);
		f1.add(tf1);
		
		
		
		
		
		
		
		l2=new JLabel("Enter Cost of Pulses Consumption");
		l2.setBounds(50,110,1000,30);
		f1.add(l2);
		
		tf2=new JTextField();
		tf2.setBounds(50,140,100,30);
		f1.add(tf2);
		
		
		

		
		
		
		
		l3=new JLabel("Enter Cost of Oils ");
		l3.setBounds(50,170,1000,30);
		f1.add(l3);
		
		tf3=new JTextField();
		tf3.setBounds(50,200,100,30);
		f1.add(tf3);
		
		
		
		
		
		
		
		
		l4=new JLabel("Enter the cost Beverages,Spices & Condiments");
		l4.setBounds(50,230,1000,30);
		f1.add(l4);
		
		tf4=new JTextField();
		tf4.setBounds(50,260,100,30);
		f1.add(tf4);
		
		
		l5=new JLabel("Enter cost Nuts,Seeds,Dry Fruits & Baking Iteams");
		l5.setBounds(50,290,1000,30);
		f1.add(l5);
		
		tf5=new JTextField();
		tf5.setBounds(50,320,100,30);
		f1.add(tf5);
		
		
		
		
		l6=new JLabel("Enter Cost of Snacks");
		l6.setBounds(50,360,1000,30);
		f1.add(l6);
		
		tf6=new JTextField();
		tf6.setBounds(50,390,100,30);
		f1.add(tf6);
		
		l7=new JLabel("Enter Cost fof Cleaning Products ");
		l7.setBounds(50,430,1000,30);
		f1.add(l7);
		
		tf7=new JTextField();
		tf7.setBounds(50,460,100,30);
		f1.add(tf7);
		
		
		
		l8=new JLabel("Enter cost of vegetables");
		l8.setBounds(50,490,1000,30);
		f1.add(l8);
		
		tf8=new JTextField();
		tf8.setBounds(50,520,100,30);
		f1.add(tf8);
		
		
		
		
		
		
		  l24=new JLabel("Enter the salalary:");
			l24.setBounds(200,520,1000,30);
		   f1.add(l24);
		   
		   	tf11=new JTextField();
		tf11.setBounds(200,550,100,30);
		f1.add(tf11);
		
		
		
		
		
		
		
		
		
	
		
		
		b5=new JButton("SUBMIT");
		b5.setBounds(50,550,100,30);
		b5.setForeground(Color.red);
		f1.add(b5);
		b5.addActionListener(this);
		
		b7=new JButton("CLEAR");
		b7.setBounds(300,550,100,30);
		b7.setForeground(Color.red);
		f1.add(b7);
		b7.addActionListener(this);
		
		
		
		
		
		
		l5=new JLabel("Display list");
		l5.setBounds(50,580,1000,30);
		f1.add(l5);
		
			tf9=new JTextField();
		tf9.setBounds(50,610,100,30);
		f1.add(tf9);
		
			b6=new JButton("press");
		b6.setBounds(50,640,100,30);
		b6.setForeground(Color.red);
		f1.add(b6);
		b6.addActionListener(this);
		
		
		
		
		
		
		
		
		
		
		
	l23=new JLabel("1.Display List");
		l23.setBounds(400,50,100,50);
		f1.add(l23);
		
		l24=new JLabel("2.Display Months Expenditure & Savings");
		l24.setBounds(400,90,400,50);
		f1.add(l24);
		
		l25=new JLabel("3.Display iteam wise Expenditure");
		l25.setBounds(400,130,400,50);
		f1.add(l25);
		
		l26=new JLabel("4.Limit & Your usage");
		l26.setBounds(400,160,400,50);
		f1.add(l26);
		
		l27=new JLabel("5.Next Month Expendicture predict");
		l27.setBounds(400,190,400,50);
		f1.add(l27);
		
		l28=new JLabel("6.Health & Environment condtion");
		l28.setBounds(400,220,400,50);
		f1.add(l28);
		
		
		l29=new JLabel("7.Exit");
		l29.setBounds(400,250,400,50);
		f1.add(l29);
		
		
		
		
		
		
		
		
		
		
		
		
		
		b8=new JButton("1");
		b8.setBounds(400,290,100,30);
		b8.setForeground(Color.red);
		f1.add(b8);
		b8.addActionListener(this);
		
		
		b9=new JButton("2");
		b9.setBounds(400,320,100,30);
		b9.setForeground(Color.red);
		f1.add(b9);
		b9.addActionListener(this);
		
		
		b10=new JButton("3");
		b10.setBounds(400,350,100,30);
		b10.setForeground(Color.red);
		f1.add(b10);
		b10.addActionListener(this);
		
		b11=new JButton("4");
		b11.setBounds(400,380,100,30);
		b11.setForeground(Color.red);
		f1.add(b11);
		b11.addActionListener(this);
		
		b12=new JButton("5");
		b12.setBounds(400,410,100,30);
		b12.setForeground(Color.red);
		f1.add(b12);
		b12.addActionListener(this);
		
		b13=new JButton("6");
		b13.setBounds(400,440,100,30);
		b13.setForeground(Color.red);
		f1.add(b13);
		b13.addActionListener(this);
		
		
		
		b14=new JButton("7");
		b14.setBounds(400,470,100,30);
		b14.setForeground(Color.red);
		f1.add(b14);
		b14.addActionListener(this);
		
		
		
		
		
		
		
		
		
		
		f1.setSize(2000,2000);
		f1.setLayout(null);
		f1.setVisible(true);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	

int u=-1;

int Grains[]=new int[100];
int Pulses[]=new int[100];
int Oils[]=new int[100];
int Spices[]=new int[100];
int Baking[]=new int[100];
int Snacks[]=new int[100];
int Cleaning[]=new int[100];
int Vegitables[]=new int[100];



int Month[]=new int[100];



int Actual_Grain=3000;
int Actual_Pulses=2000;
int Actual_Oil=3000;
int Actual_Spices=1000;
int Actual_Baking=1000;
int Actual_Snacks=500;
int Actual_Vegitables=4000;


	
	public void  actionPerformed(ActionEvent ae)
	{
		try{
		
	
		Emp obj[]=new Emp[100];

		if(ae.getSource()==b5)
		{
			 u=u+1;
			 
			 System.out.println(u);
			
	int oil1,sugar1,senamon1,rice1;
	              
				
				
				FileOutputStream fos=new FileOutputStream("hund.txt");
				  
				
			ObjectOutput oos=new ObjectOutputStream(fos);
				
			
			obj[u]=new Emp();
			Grains[u]=Integer.parseInt(tf1.getText());
			oil1=Integer.parseInt(tf1.getText());
		   obj[u].oil=oil1;
		   
			
			
			Pulses[u]=Integer.parseInt(tf2.getText());
			sugar1=Integer.parseInt(tf2.getText());
		   obj[u].sugar=sugar1;
		  
		   
		   
		   Oils[u]=Integer.parseInt(tf3.getText());
		   
		   
			
			Spices[u]=Integer.parseInt(tf4.getText());
			senamon1=Integer.parseInt(tf4.getText());
			
			
		    obj[u].senamon=senamon1;
			
			
			Baking[u]=Integer.parseInt(tf5.getText());
			rice1=Integer.parseInt(tf5.getText());
			obj[u].rice=rice1;
			
			Snacks[u]=Integer.parseInt(tf6.getText());
			Cleaning[u]=Integer.parseInt(tf7.getText());
			Vegitables[u]=Integer.parseInt(tf8.getText());
			
			
			Month[u]=Integer.parseInt(tf11.getText());
			
			
			
			
			
			
			
				oos.writeObject(obj[u]);
			
		
			
		}
if(ae.getSource()==b7)
{
	tf1.setText("");
	tf2.setText("");
	tf3.setText("");
	tf4.setText("");
	tf5.setText("");
	tf6.setText("");
	tf7.setText("");
	tf8.setText("");
}

if(ae.getSource()==b8)
{
	f1.setVisible(false);
	f2=new JFrame("frame 2");
	f2.setSize(500,500);
	f2.setBackground(Color.green);
	f2.setLayout(null);
	
	
	
	 l34=new JLabel("1.Grains");
	 l34.setBounds(200,200,300,50);
	 f2.add(l34);
	 l34.setForeground(Color.red);
	 
	l35=new JLabel("2.Oils");
	 l35.setBounds(200,230,300,50);
	 f2.add(l35);
	 l35.setForeground(Color.red);
	
	
	
	l36=new JLabel("3.Spices");
	 l36.setBounds(200,260,300,50);
	 f2.add(l36);
	 l36.setForeground(Color.red);
	
	
 l37=new JLabel("4.Baking");
  l37.setBounds(200,290,300,50);
	 f2.add(l37);
	 l37.setForeground(Color.red);
 
l38=new JLabel ("5.Snacks");
 l38.setBounds(200,320,300,50);
	 f2.add(l38);
	 l38.setForeground(Color.red);


 l39=new JLabel("6.Cleaning");
  l39.setBounds(200,350,300,50);
	 f2.add(l39);
	 l39.setForeground(Color.red);
 
 
 
 l40=new JLabel("7.Vegitables");
  l40.setBounds(200,380,300,50);
	 f2.add(l40);
	 l40.setForeground(Color.red);
 
 
	
	
	b15=new JButton("Home Page");
	b15.setBounds(50,50,200,50);
	f2.add(b15);
	 
	 b15.addActionListener(this);
	 
	 
	 f2.setVisible(true);
	
	
	
	
}
if(ae.getSource()==b15)
{
	f1.setVisible(true);
}










if(ae.getSource()==b6)
{
	int n=Integer.parseInt(tf9.getText());
	
             Emp obj1[]=new Emp[100];
			  
	 
		for(int c=0;c<n;c++)
		{
			FileInputStream fis= new FileInputStream("hund.txt");
		     ObjectInputStream ois = new ObjectInputStream(fis);
			
			obj1[c]=new Emp();
	    obj1[c]=(Emp)ois.readObject();
	
			 }
			 
			 int totalgrains=0,totalpulses=0,totaloils=0,totalbaking=0,totalsnacks=0,totalcleaning=0,totalvegetables=0;
			 int month_wise[]=new int[100];
			 
			 for(int c=0;c<n;c++)
			 {
				 totalgrains=totalgrains+Grains[c];
				 totalpulses=totalpulses+Pulses[c];
				 totaloils=totaloils+Oils[c];
				 totalbaking=totalbaking+Baking[c];
				 totalsnacks=totalsnacks+Snacks[c];
				 totalcleaning=totalcleaning+Cleaning[c];
				 totalvegetables=totalvegetables+Vegitables[c];
				 month_wise[c]=Grains[c]+Pulses[c]+Oils[c]+Baking[c]+Snacks[c]+Cleaning[c];
				 System.out.println("month"+(c+1)+"="+month_wise[c]);
				
				 
			 }
			 int max=-1;
			 int index=0;
			 
			 for(int c=0;c<n;c++)
			 {
				 if(month_wise[c]>max)
				 {
					 max=month_wise[c];
					 index=c+1;
					 
				 }
			 }
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 tf10=new JTextField();
			 tf10.setBounds(500,200,50,30);
			 this.add(tf10);
			 
			 
		 
String s=String.valueOf(index);
			 
			 tf10.setText(s);
			  l23=new JLabel("--->MONTH CONSUMPTION IS MORE");
			l23.setBounds(550,200,1000,30);
			l23.setForeground(Color.red);
		   this.add(l23);
		   
		 
		   l16=new JLabel("Granins & Iteams");
	l16.setBounds(500,50,1000,30);
	this.add(l16);
	
	
	
	
	l17=new JLabel("Pulses");
	l17.setBounds(500,70,1000,30);
	this.add(l17);
	
	
	
	l18=new JLabel("Oils");
	l18.setBounds(500,90,1000,30);
	this.add(l18);
	
	
	
	l19=new JLabel("Spices");
		
	l19.setBounds(500,110,1000,30);
	this.add(l19);
	
	
	
	
	
	
	
	l20=new JLabel("Backing iteams");
	l20.setBounds(500,130,1000,30);
	this.add(l20);
	
	
	l21=new JLabel("Snaks");
	l21.setBounds(500,150,1000,30);
	this.add(l21);
	
	
	
	
	l22=new JLabel("Cleaning products");
	l22.setBounds(500,170,1000,30);
	this.add(l22);
	
	
		   
			 
			 
			
			 System.out.println("");
			  System.out.println("");
			   System.out.println("");
			   int savings=0;
			   
			 
			 
			 
			 			 int Grains[]=new int[100];
int Pulses[]=new int[100];
int Oils[]=new int[100];
int Spices[]=new int[100];
int Baking[]=new int[100];
int Snacks[]=new int[100];
int Cleaning[]=new int[100];
int Vegitables[]=new int[100];



int Actual_Grain=3000;
int Actual_Pulses=2000;
int Actual_Oils=3000;
int Actual_Spices=1000;
int Actual_Baking=1000;
int Actual_Snacks=500;
int Actual_Cleaning=2000;
int Actual_Vegitables=4000;
			 
			 
			 while(true)
			 {
				 System.out.println("");
				  System.out.println("");
				   System.out.println("");
				 System.out.println("Select serivces:");
			 System.out.println("1.Display List");
			  System.out.println("2.Display Months Expenditure & Savings");
			   System.out.println("3.Display iteam wise Expenditure");
			 System.out.println("4.Limit & Your usage");
			System.out.println("5.Next Month Expendicture predict");
				
				  System.out.println("6.Health & Environment condtion");
				  System.out.println("7.Exit");
				  
			 Scanner sc=new Scanner(System.in);
			  System.out.println("");
			   System.out.println("");
			    System.out.println("");
				 
				 int j=sc.nextInt();
				 switch(j)
				 {
					 case 1:
					 System.out.println("Grains");
					 System.out.println("Oils");
					 System.out.println("Spices");
					 System.out.println("Baking");
					 System.out.println("Snacks");
					 System.out.println("Cleaning");
					 System.out.println("Vegitables");
					 break;
					 
					 case 2:
					 for(int i=0;i<n;i++)
			        {
						 System.out.println((i+1)+"  month Expendicture="+month_wise[i]+" Salary="+Month[i]);
				System.out.println("Grains="+Grains[i]+"+Pulses="+Pulses[i]+"+Oils="+Oils[i]+"+Spices="+Spices[i]+"+Baking="+Baking[i]+"+Snacks="+Snacks[i]+"+Cleaning="+Cleaning[i]+"+Vegitables="+Vegitables[i]);
				System.out.println("TOTAL="+month_wise[i]);
				System.out.println("Savings="+(Month[i]-month_wise[i]));
				 System.out.println("*****************************************************");
				savings=savings+(Month[i]-month_wise[i]);
				 	 
			
				
			       }
				    System.out.println("TOTAL SAVINGS:"+savings);
				   break;
				   
				   case 3:
				  
				
				   
				   System.out.println("Grains="+totalgrains);
				   System.out.println("Pulses="+totalpulses);
				    System.out.println("Oils="+totaloils);
					System.out.println("Baking="+totalbaking);
						System.out.println("Snacks="+totalsnacks);
						System.out.println("Cleaning="+totalcleaning);
						System.out.println("vegetables="+totalvegetables);
						
						
					 System.out.println("*****************************************************");
					 break;
					
				   
				     
					
					
				 
				 case 4:
				 for(int i=0;i<n;i++)
				 {
				 System.out.println("Actual Grain limit="+Actual_Grain+"  Used="+Grains[i]);
				  System.out.println("Actual Pulses limit="+Actual_Pulses+"  Used="+Pulses[i]);
				   System.out.println("Actual Oils limit="+Actual_Oil+"  Used="+Oils[i]);
				    System.out.println("Actual Baking limit="+Actual_Baking+"  Used="+Baking[i]);
					 System.out.println("Actual Snacks limit="+Actual_Snacks+"  Used="+Snacks[i]);
					  System.out.println("Actual cleaning limit="+Actual_Cleaning+"  Used="+Cleaning[i]);
					  
					  System.out.println("*****************************************************");
					 
					   System.out.println("*****************************************************");
				 
				 }
				 break;
				 
				 case 5:
				 int avg_grain=totalgrains/n,avg_pulses=totalpulses/n,avg_oil=totaloils/n,avg_baking=totalbaking/n,avg_snacks=totalsnacks/n,avg_cleaning=totalcleaning/n,avg_vegitables=totalvegetables/n;
				 
				 
				 System.out.println("Grains="+avg_grain);
				  System.out.println("Pulses"+avg_pulses);
				   System.out.println("Oils"+avg_oil);
				    System.out.println("Baking"+avg_baking);
					 System.out.println("Snacks"+avg_snacks);
					  System.out.println("Cleaning"+avg_cleaning);
					  
					  
				 
				 break;
				 case 6:
				 if(Actual_Grain>Grains[0])
				 {
					 System.out.println("Yeah! Decent Usage of");
					 System.out.println("Boiled Rice 5-7kg");
					 System.out.println("Idli Rice 5kg");
					 System.out.println("Raw Rice-2kg");
					 System.out.println("Basmati Rice 2kg");
					 System.out.println("Brown RICE -1kg");
					 System.out.println("Wheat Flour-2kg");
					 System.out.println("Maida-1kg\nRava-1kg");
				 }
				if(Actual_Grain<Grains[0])
				{
					System.out.println("Your crossing limits about Grains & Tiffn Iteams\nTry to controll");
					System.out.println("Rice has several nutrients and minerals, but despite all the good things");
					System.out.println("it is has a high glycemic index, which can actually lead to diabetes. The presence of starch");
					System.out.println("takes too much time to break down the carbs. Hence, too much of rice especially white rice must");
					System.out.println("be avoided to stay away from various lifestyle diseases");
					
				}
				  System.out.println("*****************************************************");
				  
				  
				  
				  if(Actual_Pulses>Pulses[0])
				  {
					 System.out.println("Yeah! Decent usage of ");
					System.out.println("Urad Dal");
					System.out.println("Moong Dal");
					System.out.println("Channa Dal");
					System.out.println("Chickpeas");
					System.out.println("Dried Green Peas");
					System.out.println("Green Gram ");
					System.out.println("Frozen Corn");
				  }
				  if(Actual_Pulses<Pulses[0])
				  {
					  System.out.println("Try to controll puluses Expendicture");
					  
				  }
				   System.out.println("*****************************************************");
				   
				     if(Actual_Oil>Oils[0])
				  {
					  System.out.println("Yeah! Decent usage of");
					  
					  System.out.println("Sunflower oil or vegetable oil");
					  System.out.println("Rice Bran Oil");
					 System.out.println("Sesame oil");
					  System.out.println("coconut oil");
					  System.out.println("olive oil"); 
					 System.out.println("Ghee");
				  }
				  if(Actual_Oil<Oils[0]);
				  {
					  System.out.println("Try to controll Oil usage");
					   System.out.println(" Under normal operating conditions, excess oil consumption is generally a mechanical problem");
					   System.out.println("In the majority of cases where oil consumption problems have been investigated, it usually turns out to be a leak issue");
					  System.out.println("–either the valve cover gasket is leaking, crankshaft seals leaking, or one of the main seals is leaking.");
					  
				  }
				   System.out.println("*****************************************************");
				   
				     if(Actual_Baking>Baking[0])
				  {
					  System.out.println("Yeah! Decent usage of");
					    System.out.println("Cashews");
					    System.out.println("Raisins");
					    System.out.println("Almonds");
					    System.out.println("Dates");
					    System.out.println("nuts");
				  }
				  if(Actual_Baking<Baking[0])
				  {
					  System.out.println("Try to control usage of baking iteans");
					  
				  }
				   System.out.println("*****************************************************");
				   
				   if(Actual_Cleaning<Cleaning[0])
				   {
					   System.out.println("Nice maintanince of house about cleaning");
				   }
				   
				     System.out.println("*****************************************************");
					 
					 if(Actual_Vegitables<Vegitables[0])
					 {
						 System.out.println("Nice maintanince of vegitables keep it up");
						  System.out.println("its good for health ");
						  System.out.println("A diet rich in vegetables and fruits can lower blood pressure");
						    System.out.println("reduce the risk of heart disease and stroke, prevent some types of cancer, lower risk");
						    System.out.println("of eye and digestive problems, and have a positive effect upon blood sugar, which can help keep appetite in check.");
						  
						 
					 }
					 if(Actual_Vegitables>Vegitables[0])
					 {
						  System.out.println("A diet rich in vegetables and fruits can lower blood pressure");
						    System.out.println("reduce the risk of heart disease and stroke, prevent some types of cancer, lower risk");
						    System.out.println("of eye and digestive problems, and have a positive effect upon blood sugar, which can help keep appetite in check.");
						  
						 
					 }
					 
					 break;
					 case 7:
					 System.exit(0);  
                          break;
				 }
					 
				   
				   
				  
				 
			 }
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 
		
			 
			 
			 
			 
			 

			 
			 
			 
			 
			 
			 
			 
			 
			 
			
			 
			
			 
			 
			 
			 
			 
	
		
	
	
	
	
	
	
	
	

	
	
	
	
	
			
			

			 
			 
			 

	
}

}
		catch(Exception e)
		{
		}

		
		
		/*int month_salary[]=new int[1000];
			
			
			Scanner sc=new Scanner(System.in);
			
		
		int m=1;
		
		System.out.println("enter the salary of "+m+" month:");
		
		int month_salary1=sc.nextInt();
		month_salary[m]=month_salary1;
		
		
		m=m+1;
		
		
		
		System.out.println("if u want enter the "+m+" month deatils remove old details and enterr the new values:");*/
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*if(ae.getSource()==b6)
		{
			
			
			
			
			
			
			
			
		
		int Actual_oil=1000;
		int Actual_sugar=500;
		int Actual_senamon=1000;
		int Actual_rice=2000;
			
			
		
			
			String g=tf1.getText();
			int oil1=Integer.parseInt(tf1.getText());
			
			String h=tf2.getText();
			int sugar1=Integer.parseInt(tf2.getText());
			
			String o=tf3.getText();
			int senamon1=Integer.parseInt(tf3.getText());
			
			String j=tf4.getText();
			int rice1=Integer.parseInt(tf4.getText());
			
			int total_consumed_price=oil1+sugar1+senamon1+rice1;
			
			if(total_consumed_price<month_salary[1])
		{
			l5=new JLabel("Well You Saved Something for your future...");
			this.add(l5);
			l5.setBounds(500,100,500,30);
		}
		else
		{
			l6=new JLabel("your expenditure is more than your salary.try to controll your expenditure...");
			this.add(l6);
			l6.setBounds(500,100,1000,30);
			
			
		}
		if(Actual_oil<oil1)
		{
			l7=new JLabel("Your oil consumption is greater than health condtion.,PLEASE BE IN LIMITS..");
			this.add(l7);
			l7.setBounds(500,150,1000,30);
			
			
			
			l8=new JLabel("Your oil consumption is greater than health condtion.,PLEASE BE IN LIMITS..");
			this.add(l8);
			l8.setBounds(500,200,1000,30);
			
				
			l9=new JLabel("Your family making environment damage");
			this.add(l9);
			l9.setBounds(500,250,1000,30);
			
			
			
			
			
			
			
			
		}
		else
		{
			
			l10=new JLabel("GOOD...your u using limitied oil as condtion");
			this.add(l10);
			l10.setBounds(500,150,1000,30);
			
		}
		if(Actual_sugar<sugar1)
		{
			
			l11=new JLabel("DUE TO HIGH USING SUGAR there is chance for diabetes");
			this.add(l11);
			l10.setBounds(500,300,1000,30);
			
			
			
			
		}
		else
		{
			
			l12=new JLabel("Well consuMption of sugar...keep it up");
			this.add(l12);
			l12.setBounds(500,300,1000,30);
			
		}
		
		if(Actual_rice<rice1)
		{
			l13=new JLabel("well balance die");
			this.add(l13);
			l13.setBounds(500,350,1000,30);
			
			
			
			
		}
		else{
			
				l14=new JLabel("please manage rice cz chances to come diabetes");
			this.add(l14);
			l14.setBounds(500,350,1000,30);
			System.out.println("please manage rice cz chances to come diabetes");
		}
			
			
			
			
		}
		*/
		
		
		
	
			
	}
	

	
	
	
	
	
	

	
	public static void main(String args[])
	{
	
	 
		new Test1();
		
	}
	
	}
	


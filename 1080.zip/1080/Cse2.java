package SRU;
public class Cse2
{
public void show()
{
System.out.println("cse2");
}
}
import SRU1.*;
class Sr2
{
public static void main(String args[])
{
SRU1.sr1 obj=new SRU1.sr1();
obj.show();
}

}
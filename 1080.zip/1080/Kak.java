package Ap;
public class Kak
{
public void show()
{
System.out.println("kakatiya");
}
}
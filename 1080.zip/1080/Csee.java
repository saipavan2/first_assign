package Bihar;
public class IIt
{
	public void show()
	{
		System.out.println("iit madras");
	}
}
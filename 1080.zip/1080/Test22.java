interface Test11
{
public void show();
int a=20;
}

class Test10 implements Test11
{
	public void show()
	{
		System.out.println(a);
	}
}
class Test22
{
	public static void main(String args[])
	{
		Test10 obj=new Test10();
		obj.show();
		
	}
}
class Main1{
 public static void main(String args[]) {
 int num1, num2;
int array[]=new int[6];
 try {
array[7]=9;

 }
 catch (ArithmeticException e) {
 System.out.println("You should not divide a number by zero");
 }
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("arraysize");
System.out.println(e);


}
 catch (Exception e) {
 System.out.println("Exception occurred");
 }
 System.out.println("I'm out of try-catch block in Java.");
 }
}

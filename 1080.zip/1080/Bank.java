import java.util.*;
class DExcep extends Exception
{
    void show()
    {
        System.out.println("Invalid details");
    }
}
class WExcep extends Exception
{
    void show()
    {
        System.out.println("Balance is Low...");
    }
}
class Bank
{
    double amount;
    Bank()
    {
        amount=0;
    }
    void deposit(double d)
    {
        amount+=d;
    }
    void withdrawl(double d)
    {
        amount-=d;
    }
    double balance()
    {
        return amount;
    }
}
class BankMain
{
    public static void main(String ar[])
    {
        String accno="987654321",pswd="1234@5";
        String acc=null;
        String pwd=null;
        //int choice=0;
        double amt=0;
        double amt1=0;
        Scanner sc=new Scanner(System.in);
        Bank obj=new Bank();
        while(true)
        {
                    System.out.println("||--->Menu<---||");
                    System.out.println("1:Deposit\n2.Withdraw\n3.Check Balance\n4.Exit");
                    System.out.println("Enter Your choice:");
                    int choice=sc.nextInt();
                    String ch = sc.nextLine();
                    switch(choice)
                    {
                        case 1:
                                System.out.println("You are Depositing your amount...");
                                System.out.println("Enter accno:");
                                acc=sc.nextLine();
                                System.out.println("Enter Password:");
                                pwd=sc.nextLine();
                                try
                                {
                                    if(acc.equals(accno) && pwd.equals(pswd))
                                    {
                                        System.out.println("Enter the amount to deposit:");
                                        amt=sc.nextInt();  
                                        obj.deposit(amt);
                                    }
                                    else
                                    {
                                        throw new DExcep();
                                    }
                                }
                                catch(DExcep e)
                                {
                                    e.show();
                                }
                            break;
                        case 2:
                                System.out.println("You are withdrawing your amount...");
                                System.out.println("Enter accno:");
                                acc=sc.nextLine();
                                System.out.println("Enter Password:");
                                pwd=sc.nextLine();
                                try
                                {
                                    if(acc.equals(accno) && pwd.equals(pswd))
                                    {
                                        System.out.println("Enter the amount to withdraw:");
                                        amt1=sc.nextInt();
                                        try
                                        {
                                            if(amt1<=obj.amount)
                                            {
                                                obj.withdrawl(amt1);
                                            }  
                                            else
                                            {
                                                throw new WExcep();
                                            }
                                        }
                                        catch(WExcep e)
                                        {
                                            e.show();
                                        }
                                    }
                                    else
                                    {
                                        throw new DExcep();
                                    }
                                }
                                catch(DExcep e)
                                        {
                                            e.show();
                                        }
                            break;
                        case 3: 
                            System.out.println("You are viewing your balance...");
                            System.out.println("Enter accno:");
                            acc=sc.nextLine();
                            System.out.println("Enter Password:");
                            pwd=sc.nextLine();
                            try
                            {
                                if(acc.equals(accno) && pwd.equals(pswd))
                                {
                                    System.out.println("Balance in the account is: "+ obj.balance());
                                }
                                else
                                {
                                    throw new DExcep();
                                }
                            }
                            catch(DExcep e)
                            {
                                e.show();
                            }
                            break;
                        case 4:
                            System.exit(0);
                    }
        }
    }
}

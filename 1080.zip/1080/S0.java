package Sad1;
public class S0
{
public void display()
{
System.out.println("sadiq1");
}

}
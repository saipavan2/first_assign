package SRU;
public class CseB
{
public void show()
{
System.out.println("cse b");
}
}
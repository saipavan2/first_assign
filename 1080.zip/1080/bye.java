import java.io.*;
class Bye
{
	public static void main(String args[])
	{
		try
		{
		FileOutputStream fos=new FileOutputStream("56.txt");
		fos.write(90);
		fos.close();
		}catch(Exception e)
		{
		}
	}
}
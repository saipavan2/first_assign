class exception_1
{
	public static void main(String[] args)
	{
		int balance=500;
		int withdralAmount=6000;
		try
		{
			if(balance<withdralAmount)
			{
				throw new ArithmeticException("insufficicent");
			}
			else
			{
			balance=balance-withdralAmount;
			System.out.println("Transacton Successfully completed");
			}
		}catch(ArithmeticException e)
		{
			System.out.println("Exception"+e.getMessage());
		}
		System.out.println("program continue...");
	}
}
//compile this code wherever u want. 
 import java.io.*;
import java.lang.*;
 import java.util.*;
 import javax.swing.*;
 import java.awt.*;
 import java.awt.event.*;
 
//class


interface I1  //interface
{
	
	int a=10;
}

	                //inheretence
public class WMail extends JFrame implements ActionListener,I1
{
	//swings
	JFrame f1,f2,f3,f4,f5,f6;
	JTextField tf1,tf2,tf3,tf4,tf5,tf6;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	JButton b1,b2,b3,b4,b5;
  WMail()
  {
	  f1=new JFrame("frame 1");//override
	  
	  l1=new JLabel("Enter function (SignUp, Login, Compose):");
	  l1.setBounds(100,100,1000,50);
	  f1.add(l1);
	  
	  
	  tf1=new JTextField();
	  tf1.setBounds(100,170,200,30);
	  f1.add(tf1);
	  
	  b1=new JButton("Enter");
	  b1.setBounds(100,210,200,30);
	  f1.add(b1);
	 b1.addActionListener(this);
	  
	  f1.setSize(500,500);
	  f1.setLayout(null);
	  f1.setVisible(true);
	  
	  
	  
   
}
String data;
String Composed;
String data1;


//accessmodifiers

public void actionPerformed(ActionEvent ae)
{
	try{
	//this keyword
	this.data1="login";
	String ch;
	if(ae.getSource()==b1)
	{
		ch=tf1.getText();
		 

//strings		 
    if(ch.equals("signup"))
    {
    
    InputStreamReader reader=new InputStreamReader(System.in);
    BufferedReader input=new BufferedReader(reader);
    System.out.print("Username@wmail.com: ");
    java.lang.String User=input.readLine();
    System.out.print("Password: ");
    java.lang.String Pass=input.readLine();
    
    System.out.println("New ID created successfully!");
    
    FileWriter fout=new FileWriter(User+"@wmail.com");
    BufferedWriter bout=new BufferedWriter(fout);
    PrintWriter pout=new PrintWriter(bout);
    pout.println(Pass);
    
    FileWriter fot=new FileWriter(User);
    BufferedWriter bot=new BufferedWriter(fot);
    PrintWriter pot=new PrintWriter(bot);
    
    pout.close();
    bout.close();
    pout.close();
    }
    
    else
    if(ch.equals("login"))
    {
  
   
    
    InputStreamReader reader=new InputStreamReader(System.in);
    BufferedReader input=new BufferedReader(reader);
    System.out.print("Username: ");
    java.lang.String User=input.readLine();
    System.out.print("Password: ");
    java.lang.String Pass=input.readLine();
    
    FileReader fout=new FileReader(User+"@wmail.com");
    BufferedReader bout=new BufferedReader(fout);
    
    java.lang.String data=bout.readLine();
    if(Pass.equals(data))
    {
    System.out.println("Logged On!");
    System.out.print("Do you want to go to the inbox: (yes/no)");
    java.lang.String Ask=input.readLine();
    if(Ask.equals("yes"))
    {
    FileReader f=new FileReader(User);
    BufferedReader b=new BufferedReader(f);
    System.out.println("");
    java.lang.String Composed;
    int i=0;
    while((Composed=b.readLine())!=null)
    {
    i++;
    System.out.println(Composed);
    }
    System.out.println("");
    b.close();
    bout.close();
    }
   

    }
    else
    {
    System.out.println("Wrong password!");
    }
    }
    
    else
    if(ch.equals("compose"))
    {
    
    InputStreamReader reader=new InputStreamReader(System.in);
    BufferedReader input=new BufferedReader(reader);
    Calendar c=Calendar.getInstance();
    
    System.out.print("Username: ");
    java.lang.String User1=input.readLine();
    System.out.print("Password: ");
    java.lang.String Pass=input.readLine();
    
    FileReader fout=new FileReader(User1+"@wmail.com");
    BufferedReader bout=new BufferedReader(fout);
    
    java.lang.String data=bout.readLine();
    if(Pass.equals(data))
    {
    System.out.println("Logged On!");
    
    System.out.print("To:   ");
    java.lang.String User=input.readLine();
    
    System.out.print("From:   ");
    java.lang.String From=input.readLine();
    System.out.println("");
    System.out.println("Letter Content:");
    java.lang.String Body=input.readLine();
    
    FileWriter fin=new FileWriter(User);
    BufferedWriter bin=new BufferedWriter(fin);
    PrintWriter pin=new PrintWriter(bin);
    System.out.println("");
    pin.println("Time:"+c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+" PM");
    pin.println("From "+From+",");
    pin.println(Body);
    System.out.println("");
    System.out.println("Mail sent!");
    bout.close();
    pin.close();
    bin.close();
    pin.close();
    }
    else
    {
    System.out.println("Wrong password!");
    }
    
  
    }
    else
    System.out.println("Wrong choice!");
    }
	
	}catch(Exception e)
	{
	}
	
}
    

	



	public static void main(String args[])
	{
		//object
		new WMail();
		
	}
	
	
    }
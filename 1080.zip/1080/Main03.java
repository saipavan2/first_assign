class Box
{
int width=10;
int height;
int depth;
int vol;
void display()
{
  System.out.println("volume:"+vol);
}

}
class Main03
{
public static void main(String args[])
{
Box mybox=new Box();
mybox.width=10;
mybox.height=20;
mybox.depth=30;
mybox.vol=mybox.width*mybox.height*mybox.depth;
mybox.display();

}
}
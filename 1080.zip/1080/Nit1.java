package Punjab;
public class Nit1
{
	public void show()
	{
		System.out.println("Nit panjab");
	}
}
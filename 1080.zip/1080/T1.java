class T1 extends Thread
{

public void run()
{
for(int i=0;i<10;i++)
{
System.out.println("thread..."+i+""+i);
}
}
}
class MainT1
{
public static void main(String args[])
{
T1 t1=new T1();
t1.start();
}
}
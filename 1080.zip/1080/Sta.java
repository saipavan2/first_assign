class Stack
{
int stck[]=new int[10];
int tos;
Stack()
{
tos=-1;
}
void push(int item)
{
if(tos==9)
System.out.println("stack is overflow");
else
stck[++tos]=item;
}
int pop()
{
if(tos<0)
{
System.out.println("stack is underflow");
return 0;
}
else
return stck[tos--];
}
}
class Sta
{
public static void main(String args[])
{
Stack ob1=new Stack();
Stack ob2=new Stack();

int i;
for(i=0;i<10;i++)
ob1.push(i);
for(i=10;i<20;i++)
ob2.push(i);
System.out.println("stack of ob1");
for(i=0;i<10;i++)
System.out.println(ob1.pop());

System.out.println("stack of ob2");
for(i=0;i<10;i++)
System.out.println(ob2.pop());

}

}

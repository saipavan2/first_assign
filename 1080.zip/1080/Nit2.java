package Bengal;
public class Nit2
{
	public void show()
	{
		System.out.println("Nit Bengal");
	}
}
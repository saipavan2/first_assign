import java.util.*;
class Task1
{
public static void main(String args[])
{
int a=10,b=20,c=30;
Scanner sc=new Scanner(System.in);
System.out.println("enter the x:");
int x=sc.nextInt();
System.out.println("enter the y:");
int y=sc.nextInt();


System.out.println("ax+bx+c=");
System.out.print(a*x+b*y+c);

}
}
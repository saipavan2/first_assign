import javax.swing.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*; 

import java.io.*;
import java.util.*;

		
		class emp implements Serializable
{
	int oil;
	int sugar;
	int senamon;
	int rice;
	
}



class Bye extends JFrame implements ActionListener
{
	
	
		
		
		JButton b1,b2,b3,b4,b5,b6;
		JTextField tf1,tf2,tf3,tf4,tf5;
		JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	 Bye()
	{
		
		int Actual_oil=1000;
		int Actual_sugar=500;
		int Actual_senamon=1000;
		int Actual_rice=2000;
	
		
		
		
		
		
		
		
	
		
		
		l1=new JLabel("ente the oil consumed in this month:");
		l1.setBounds(50,50,1000,30);
		this.add(l1);
		
		tf1=new JTextField();
		tf1.setBounds(50,100,100,30);
		this.add(tf1);
		
		
		
		
		
		b1=new JButton("press");
		b1.setBounds(50,150,100,30);
		this.add(b1);
		b1.addActionListener(this);
		
		
		l2=new JLabel("ente the sugar consumed in this month:");
		l2.setBounds(50,200,1000,30);
		this.add(l2);
		
		tf2=new JTextField();
		tf2.setBounds(50,250,100,30);
		this.add(tf2);
		
		
		
		
		b2=new JButton("press");
		b2.setBounds(50,300,100,30);
		this.add(b2);
		b2.addActionListener(this);
		
		
		
		
		
		
		l3=new JLabel("enter the senamon price consumed for:");
		l3.setBounds(50,350,1000,30);
		this.add(l3);
		
		tf3=new JTextField();
		tf3.setBounds(50,400,100,30);
		this.add(tf3);
		
		
		
		
		b3=new JButton("press");
		b3.setBounds(50,450,100,30);
		this.add(b3);
		b3.addActionListener(this);
		
		
		
		
		
		
		l4=new JLabel("enter the rice price consumed for :");
		l4.setBounds(50,500,1000,30);
		this.add(l4);
		
		tf4=new JTextField();
		tf4.setBounds(50,550,100,30);
		this.add(tf4);
		
		
		
		
		b4=new JButton("press");
		b4.setBounds(50,600,100,30);
		this.add(b4);
		b4.addActionListener(this);
		
		
		
		
		b5=new JButton("total expenditure month wise");
		b5.setBounds(50,650,100,30);
		b5.setForeground(Color.red);
		this.add(b5);
		b5.addActionListener(this);
		
		
		
			
		b6=new JButton("calculate this month");
		b6.setBounds(500,50,500,30);
		b6.setForeground(Color.red);
		this.add(b6);
		b6.addActionListener(this);
		
		
		this.setSize(2000,2000);
		this.setLayout(null);
		this.setVisible(true);
		
	}
	
	
	
	
	
	

	
	
	public void  actionPerformed(ActionEvent ae)
	{
		
	
		if(ae.getSource()==b1)
		{
			
		}
		if(ae.getSource()==b2)
		{
			
		}
		
		
		if(ae.getSource()==b3)
		{
			
		}
		
		
		if(ae.getSource()==b4)
		{
			
		}
		
		if(ae.getSource()==b5)
		{
		
		}
			
			
			
}
		public static void main(String args[])
	{
	 Scanner sc=new Scanner(System.in);
	 
		new Bye();
		
	}
	
	}
	


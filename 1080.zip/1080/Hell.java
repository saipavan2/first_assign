class A
{
void display()
{
System.out.println("in A");
}
}
class B extends A
{
void display()
{
System.out.println("in B");
}
}
class Hell
{
public static void main(String args[])
{
Second obj=new Second();
obj.display();
}
}
import java.util.*;
class A
{  
public static void main(String args[])
{  
int sum1=0,sum2=0,i;

int atm[]={1,2,3,4,5,6,7,8,9};
for(i=0;i<9;i=i+2)
{
sum1=sum1+atm[i];

}
for(i=1;i<9;i=i+2)
{
sum2=sum2+atm[i];

}
if(sum1==sum2)
{
System.out.println("valid");
}
else
{
System.out.println("not valid");
}


 
}  
}  
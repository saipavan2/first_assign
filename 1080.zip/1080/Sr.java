package Tel;
public class Sr
{
public void show()
{
System.out.println("sr");
}
}
package SRU1;

public class Sr3
{
	public void show()
	{
		System.out.println("excecuting package");
	}
}

import Bihar.*;
class Nit
{
	public static void main(String args[])
	{
		Bihar.Iit obj=new Bihar.Iit();
		obj.show();
	}
}
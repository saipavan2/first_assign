class Test1 implements Runnable
{
public void run()
{
System.out.println("thread task2");
}
}
class Test
{
public static void main(String args[])
{
Test t=new Test();
Thread th=new Thread(t);
th.start();
}
}

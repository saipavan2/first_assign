class A
{
int a;
void show()
{
a=20;
}
void dis()
{
System.out.println(a+1);
}
}

class Ma
{
public static void main(String args[])
{
A obj=new A();
obj.dis();
}
}

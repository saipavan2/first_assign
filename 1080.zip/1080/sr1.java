Package SRU1;

public class Sr1
{
	public void show()
	{
		System.out.println("excecuting package");
	}
}

class Box1
{
int height;
int width;
int depth;
}
class Box2
{
int h;
int w;
int d;
}
class Main01
{
public static void main(String args[])
{
Box1 mybox1=new Box1();
Box2 mybox2=new Box2();
mybox1.height=1;
mybox2.h=2;
System.out.println(mybox1.height);
System.out.println(mybox2.h);

}
}
import SRU1.*;
class Sr5
{
public static void main(String args[])
{
SRU1.Sr4 obj=new SRU1.Sr4();
obj.show();
}

}
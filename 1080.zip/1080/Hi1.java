import javax.swing.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
class Hi
{
	public static void main(String args[])
	{
		Hi1 obj=new Hi1();
	}
	
}




class Hi1 extends JFrame implements ActionListener
{
	
	
		Hi1
		{
	
			JLabel l1,l2;
			JButton b1;
			JTextField t1,t2;
			
			l1=new JLabel("Enter how much area of land the farmer had:");
			l1.setForeground(Color.RED);
			l1.add(this);
			l1.setBounds(50,50,1000,30);
			
			t1=new JTextField(20);
			t1.add(this);
			t1.setBounds(50,90,100,30);
			
			t2=new JTextField(20);
			t2.setBounds(50,200,100,30);
			t2.add(this);
			
			b1=new JButton("ok");
			b1.addActionListener(this);
			
			
			
		setSize(1000,1000);
	setLayout(null);
		
	setVisible(true);
		}
	
	
	public void actionPerformed(ActionEvent ae)
    {
    int num1=Integer.parseInt(t1.getText());
   t2.setText(String.valueOf(num1));
    }
			
			
		
	
}
			